// Elements
const editBtn = document.getElementById("editBtn")
const editModal = document.getElementById("editModal")
const cancelBtn = document.getElementById("cancelBtn")
const saveBtn = document.getElementById("saveBtn")
const banner = document.getElementById("banner")
const profilePicture = document.getElementById("profilePicture")
const profileImg = document.getElementById("profileImg")
const profileName = document.getElementById("profileName")
const profileBio = document.getElementById("profileBio")
const bannerInput = document.getElementById("bannerInput")
const avatarInput = document.getElementById("avatarInput")
const nameInput = document.getElementById("nameInput")
const bioInput = document.getElementById("bioInput")

let currentUser = null 
document.addEventListener("DOMContentLoaded", async () => {
  checkUserSession()
  loadProfile()
  loadUserStatsFromLocalStorage() 
})

function checkUserSession() {
  const userStr = localStorage.getItem("currentUser")
  if (!userStr) {
    window.location.href = "../login/login.html"
    return
  }
  currentUser = JSON.parse(userStr)

  profileName.textContent = currentUser.nome
  nameInput.value = currentUser.nome
}

function getUserStorageKey(key) {
  return `${key}_${currentUser.email}`
}

function loadUserStatsFromLocalStorage() {
  const savedStats = localStorage.getItem(getUserStorageKey("userStats"))
  const savedHabits = localStorage.getItem(getUserStorageKey("habits"))

  if (savedStats) {
    const userStats = JSON.parse(savedStats)
    document.getElementById("userTrophies").textContent = userStats.achievements.length
    document.getElementById("userLevel").textContent = userStats.level
    document.getElementById("userStreak").textContent = userStats.streak
  }

  if (savedHabits) {
    const habits = JSON.parse(savedHabits)
    document.getElementById("userHabits").textContent = habits.length
  }

  loadTrophies()
}

function loadProfile() {
  const savedBanner = localStorage.getItem(getUserStorageKey("banner"))
  const savedAvatar = localStorage.getItem(getUserStorageKey("avatar"))
  const savedName = localStorage.getItem(getUserStorageKey("name"))
  const savedBio = localStorage.getItem(getUserStorageKey("bio"))

  if (savedBanner) {
    banner.style.backgroundImage = `url(${savedBanner})`
  }
  if (savedAvatar) {
    profileImg.src = savedAvatar
  }
  if (savedName) {
    profileName.textContent = savedName
    nameInput.value = savedName
  }
  if (savedBio) {
    profileBio.textContent = savedBio
    bioInput.value = savedBio
  }
}

editBtn.addEventListener("click", () => {
  editModal.classList.add("active")
})

cancelBtn.addEventListener("click", () => {
  editModal.classList.remove("active")
})

editModal.addEventListener("click", (e) => {
  if (e.target === editModal) {
    editModal.classList.remove("active")
  }
})

bannerInput.addEventListener("change", (e) => {
  const file = e.target.files[0]
  if (file) {
    const reader = new FileReader()
    reader.onload = (event) => {
      banner.style.backgroundImage = `url(${event.target.result})`
      localStorage.setItem(getUserStorageKey("banner"), event.target.result)
    }
    reader.readAsDataURL(file)
  }
})

avatarInput.addEventListener("change", (e) => {
  const file = e.target.files[0]
  if (file) {
    const reader = new FileReader()
    reader.onload = (event) => {
      profileImg.src = event.target.result
      localStorage.setItem(getUserStorageKey("avatar"), event.target.result)
    }
    reader.readAsDataURL(file)
  }
})

saveBtn.addEventListener("click", () => {
  const name = nameInput.value.trim()
  const bio = bioInput.value.trim()

  if (name) {
    profileName.textContent = name
    localStorage.setItem(getUserStorageKey("name"), name)
  }

  if (bio) {
    profileBio.textContent = bio
    localStorage.setItem(getUserStorageKey("bio"), bio)
  }

  editModal.classList.remove("active")
})

function loadTrophies(serverData = null) {
  const savedStats = localStorage.getItem(getUserStorageKey("userStats"))
  const savedImages = localStorage.getItem(getUserStorageKey("achievementsCustomImages"))
  const trophyShelf = document.getElementById("trophyShelf")

  const ACHIEVEMENTS = [
    { id: "first_habit", icon: "🌱", name: "Primeira Semente" },
    { id: "habit_master", icon: "🎯", name: "Mestre dos Hábitos" },
    { id: "week_warrior", icon: "⚔️", name: "Guerreiro Semanal" },
    { id: "month_legend", icon: "👑", name: "Lenda Mensal" },
    { id: "perfect_day", icon: "✨", name: "Dia Perfeito" },
    { id: "early_bird", icon: "🌅", name: "Pássaro Madrugador" },
    { id: "night_owl", icon: "🦉", name: "Coruja Noturna" },
    { id: "level_5", icon: "⭐", name: "Estrela em Ascensão" },
    { id: "level_10", icon: "💎", name: "Diamante" },
    { id: "points_1000", icon: "💯", name: "Milionário de Pontos" },
  ]

  const customImages = {}
  if (savedImages) {
    const imagesData = JSON.parse(savedImages)
    imagesData.forEach((item) => {
      if (item.customImage) {
        customImages[item.id] = item.customImage
      }
    })
  }

  let unlockedAchievements = []
  if (serverData && serverData.achievements) {
    unlockedAchievements = serverData.achievements
  } else if (savedStats) {
    const userStats = JSON.parse(savedStats)
    unlockedAchievements = userStats.achievements || []
  }

  trophyShelf.innerHTML = ""

  for (let i = 0; i < 12; i++) {
    const trophyItem = document.createElement("div")
    trophyItem.className = "trophy-item"

    if (i < ACHIEVEMENTS.length && unlockedAchievements.includes(ACHIEVEMENTS[i].id)) {
      const achievement = ACHIEVEMENTS[i]
      const customImage = customImages[achievement.id]

      if (customImage) {
        trophyItem.innerHTML = `
          <div class="trophy-icon"><img src="${customImage}" alt="${achievement.name}"></div>
          <div class="trophy-name">${achievement.name}</div>
        `
      } else {
        trophyItem.innerHTML = `
          <div class="trophy-icon" style="font-size: 60px;">${achievement.icon}</div>
          <div class="trophy-name">${achievement.name}</div>
        `
      }
    } else {
      trophyItem.innerHTML = `
        <div class="trophy-icon"><img src="https://i.postimg.cc/q7z21J3y/sem-traco.png" alt="Bloqueado"></div>
        <div class="trophy-name">Bloqueado</div>
      `
    }

    trophyShelf.appendChild(trophyItem)
  }
}
