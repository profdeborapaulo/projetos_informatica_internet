
const container = document.getElementById("container")
const registerBtn = document.getElementById("register")
const loginBtn = document.getElementById("login")

registerBtn.addEventListener("click", () => {
  container.classList.add("active")
})

loginBtn.addEventListener("click", () => {
  container.classList.remove("active")
})

const signupButton = document.getElementById("signup-button")
const loginButton = document.getElementById("login-button")
const signupMessage = document.getElementById("signup-message")
const loginMessage = document.getElementById("login-message")

function getAllUsers() {
  const usersJson = localStorage.getItem("allUsers")
  return usersJson ? JSON.parse(usersJson) : []
}

function saveAllUsers(users) {
  localStorage.setItem("allUsers", JSON.stringify(users))
}

function findUserByEmail(email) {
  const users = getAllUsers()
  return users.find((user) => user.email === email)
}

signupButton.addEventListener("click", () => {
  const nome = document.getElementById("signup-name").value.trim()
  const email = document.getElementById("signup-email").value.trim()
  const senha = document.getElementById("signup-password").value.trim()

  if (!nome || !email || !senha) {
    signupMessage.textContent = "Preencha todos os campos!"
    signupMessage.style.color = "#d32f2f"
    return
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(email)) {
    signupMessage.textContent = "Email inválido!"
    signupMessage.style.color = "#d32f2f"
    return
  }

  const existingUser = findUserByEmail(email)
  if (existingUser) {
    signupMessage.textContent = "Email já cadastrado!"
    signupMessage.style.color = "#d32f2f"
    return
  }

  const users = getAllUsers()
  const newUser = {
    id: Date.now().toString(),
    nome,
    email,
    senha, 
    criadoEm: new Date().toISOString(),
  }

  users.push(newUser)
  saveAllUsers(users)

  showNotification("Cadastro realizado com sucesso!", "success")

  signupMessage.textContent = "Cadastro realizado com sucesso!"
  signupMessage.style.color = "#4caf50"

  document.getElementById("signup-name").value = ""
  document.getElementById("signup-email").value = ""
  document.getElementById("signup-password").value = ""

  setTimeout(() => {
    container.classList.remove("active")
    signupMessage.textContent = ""
  }, 2000)
})

loginButton.addEventListener("click", () => {
  const email = document.getElementById("login-email").value.trim()
  const senha = document.getElementById("login-password").value.trim()

  if (!email || !senha) {
    loginMessage.textContent = "Preencha todos os campos!"
    loginMessage.style.color = "#d32f2f"
    return
  }

  const user = findUserByEmail(email)

  if (!user || user.senha !== senha) {
    loginMessage.textContent = "Email ou senha incorretos!"
    loginMessage.style.color = "#d32f2f"
    return
  }

  loginMessage.textContent = `Bem-vindo, ${user.nome}!`
  loginMessage.style.color = "#4caf50"

  localStorage.setItem("currentUser", JSON.stringify(user))
  
  showNotification(`Bem-vindo, ${user.nome}!`, "success")

  document.getElementById("login-email").value = ""
  document.getElementById("login-password").value = ""

  setTimeout(() => {
    window.location.href = "../home/home.html"
  }, 1500)
})

function showNotification(message, type = "success") {
  const notification = document.createElement("div")
  notification.className = `notification notification-${type}`
  notification.textContent = message

  const styles = {
    position: "fixed",
    top: "20px",
    right: "20px",
    background: type === "success" ? "#10b981" : type === "error" ? "#ef4444" : "#3b82f6",
    color: "white",
    padding: "1rem 1.5rem",
    borderRadius: "8px",
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.3)",
    zIndex: "10000",
    fontWeight: "bold",
    fontSize: "0.875rem",
    animation: "slideIn 0.3s ease, fadeOut 0.3s ease 2.7s",
  }

  Object.assign(notification.style, styles)
  document.body.appendChild(notification)

  setTimeout(() => {
    notification.remove()
  }, 3000)
}

const style = document.createElement("style")
style.textContent = `
  @keyframes slideIn {
    from {
      transform: translateX(400px);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  @keyframes fadeOut {
    from {
      opacity: 1;
    }
    to {
      opacity: 0;
    }
  }
`
document.head.appendChild(style)
