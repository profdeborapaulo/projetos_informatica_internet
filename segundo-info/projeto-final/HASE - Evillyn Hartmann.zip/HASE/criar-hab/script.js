
let habits = []
let currentFilter = "all"
let selectedIcon = "💧"
let selectedColor = "#06b6d4"
let selectedType = "saudavel"
let editingHabitId = null
let currentHour = null
let currentMinute = null
let currentDay = null

const ACHIEVEMENTS = [
  {
    id: "first_habit",
    icon: "🌱",
    name: "Primeira Semente",
    desc: "Crie seu primeiro hábito",
    condition: () => habits.length >= 1,
    customImage: null,
  },
  {
    id: "habit_master",
    icon: "🎯",
    name: "Mestre dos Hábitos",
    desc: "Crie 5 hábitos",
    condition: () => habits.length >= 5,
    customImage: null,
  },
  {
    id: "week_warrior",
    icon: "⚔️",
    name: "Guerreiro Semanal",
    desc: "Mantenha uma sequência de 7 dias",
    condition: () => userStats.streak >= 7,
    customImage: null,
  },
  {
    id: "month_legend",
    icon: "👑",
    name: "Lenda Mensal",
    desc: "Mantenha uma sequência de 30 dias",
    condition: () => userStats.streak >= 30,
    customImage: null,
  },
  {
    id: "perfect_day",
    icon: "✨",
    name: "Dia Perfeito",
    desc: "Complete todos os hábitos em um dia",
    condition: () => checkPerfectDay(),
    customImage: null,
  },
  {
    id: "early_bird",
    icon: "🌅",
    name: "Pássaro Madrugador",
    desc: "Complete 10 hábitos matinais",
    condition: () => countCompletedByPeriod("morning") >= 10,
    customImage: null,
  },
  {
    id: "night_owl",
    icon: "🦉",
    name: "Coruja Noturna",
    desc: "Complete 10 hábitos noturnos",
    condition: () => countCompletedByPeriod("evening") >= 10,
    customImage: null,
  },
  {
    id: "level_5",
    icon: "⭐",
    name: "Estrela em Ascensão",
    desc: "Alcance o nível 5",
    condition: () => userStats.level >= 5,
    customImage: null,
  },
  {
    id: "level_10",
    icon: "💎",
    name: "Diamante",
    desc: "Alcance o nível 10",
    condition: () => userStats.level >= 10,
    customImage: null,
  },
  {
    id: "points_1000",
    icon: "💯",
    name: "Milionário de Pontos",
    desc: "Acumule 1000 pontos",
    condition: () => userStats.points >= 1000,
    customImage: null,
  },
]

const userStats = {
  level: 0,
  points: 0,
  streak: 0,
}

function countCompletedByPeriod(period) {
  const today = new Date().getDay()
  let count = 0
  habits.forEach((habit) => {
    if (habit.period === period && habit.days.includes(today)) {
      const todayProgress = habit.progress[getTodayDateString()] || 0
      if (todayProgress >= habit.goalValue) {
        count++
      }
    }
  })
  return count
}

const daysOfWeek = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"]

const daysOfWeekShort = ["DOM", "SEG", "TER", "QUA", "QUI", "SEX", "SÁB"]

const monthsOfYear = [
  "JANEIRO",
  "FEVEREIRO",
  "MARÇO",
  "ABRIL",
  "MAIO",
  "JUNHO",
  "JULHO",
  "AGOSTO",
  "SETEMBRO",
  "OUTUBRO",
  "NOVEMBRO",
  "DEZEMBRO",
]

document.addEventListener("DOMContentLoaded", () => {
  loadHabits()
  initializeDate()
  updateClock()
  setInterval(updateClock, 1000)
  renderHabits()
  setupEventListeners()
})

function initializeDate() {
  const now = new Date()
  const dayName = daysOfWeek[now.getDay()]
  const dayNumber = now.getDate()
  const monthName = monthsOfYear[now.getMonth()]
  const weekdayShort = daysOfWeekShort[now.getDay()]

  document.getElementById("dayName").textContent = dayName
  document.getElementById("dayNumber").textContent = dayNumber
  document.getElementById("monthName").textContent = monthName
  document.getElementById("weekdayLabel").textContent = weekdayShort

  currentDay = dayNumber
}

function updateDate() {
  const now = new Date()
  if (now.getDate() !== currentDay) {
    initializeDate() 
  }
}

function flipCard(element, oldValue, newValue) {
  const topElement = element.querySelector(".flip-card-top .flip-content")
  const bottomElement = element.querySelector(".flip-card-bottom .flip-content")
  topElement.textContent = oldValue
  bottomElement.textContent = oldValue

  element.classList.add("animating")
  setTimeout(() => {
    topElement.textContent = newValue
    bottomElement.textContent = newValue
    element.classList.remove("animating")
  }, 600)
}

function updateClock() {
  const now = new Date()
  const hours = String(now.getHours()).padStart(2, "0")
  const minutes = String(now.getMinutes()).padStart(2, "0")

  const hourFlip = document.getElementById("hourFlip")
  const minuteFlip = document.getElementById("minuteFlip")

  if (currentHour !== null && currentHour !== hours) {
    flipCard(hourFlip, currentHour, hours)
  } else if (currentHour === null) {
    document.getElementById("hourTop").textContent = hours
    document.getElementById("hourBottom").textContent = hours
  }

  if (currentMinute !== null && currentMinute !== minutes) {
    flipCard(minuteFlip, currentMinute, minutes)
  } else if (currentMinute === null) {
    document.getElementById("minuteTop").textContent = minutes
    document.getElementById("minuteBottom").textContent = minutes
  }

  currentHour = hours
  currentMinute = minutes

  document.getElementById("weekdayLabel").textContent = daysOfWeekShort[now.getDay()]

  updateDate()
}

function setupEventListeners() {
  const menuBtn = document.querySelector(".menu-btn")
  const menuDropdown = document.querySelector(".menu-dropdown")

  menuBtn.addEventListener("click", () => {
    if (menuDropdown.style.display === "flex") {
      menuDropdown.style.display = "none"
    } else {
      menuDropdown.style.display = "flex"
    }
  })

  document.addEventListener("click", (e) => {
    if (!e.target.closest(".menu-container")) {
      menuDropdown.style.display = "none"
    }
  })

  document.getElementById("btnLogout").addEventListener("click", (e) => {
    e.preventDefault()
    if (confirm("Tem certeza que deseja sair?")) {
      localStorage.clear()
      window.location.href = "../login/login.html"
    }
  })

  document.getElementById("fabButton").addEventListener("click", openCreateModal)

  document.getElementById("btnBack").addEventListener("click", closeModal)
  document.getElementById("btnClose").addEventListener("click", closeModal)
  document.getElementById("modalOverlay").addEventListener("click", (e) => {
    if (e.target.id === "modalOverlay") closeModal()
  })

  document.getElementById("iconSelector").addEventListener("click", () => {
    const picker = document.getElementById("iconPicker")
    picker.style.display = picker.style.display === "none" ? "block" : "none"
  })

  document.querySelectorAll(".icon-option").forEach((btn) => {
    btn.addEventListener("click", () => {
      selectedIcon = btn.dataset.icon
      document.getElementById("selectedIcon").textContent = selectedIcon
      document.getElementById("iconPicker").style.display = "none"
    })
  })

  document.querySelectorAll(".color-option").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".color-option").forEach((b) => b.classList.remove("active"))
      btn.classList.add("active")
      selectedColor = btn.dataset.color
      document.getElementById("iconSelector").style.background =
        `linear-gradient(135deg, ${selectedColor} 0%, ${adjustColor(selectedColor, -20)} 100%)`
    })
  })

  document.querySelectorAll(".btn-toggle").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".btn-toggle").forEach((b) => b.classList.remove("active"))
      btn.classList.add("active")
      selectedType = btn.dataset.type
    })
  })

  document.querySelectorAll(".day-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      btn.classList.toggle("active")
    })
  })

  document.querySelectorAll(".filter-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".filter-btn").forEach((b) => b.classList.remove("active"))
      btn.classList.add("active")
      currentFilter = btn.dataset.filter
      renderHabits()
    })
  })

  document.getElementById("habitForm").addEventListener("submit", handleFormSubmit)

  document.getElementById("btnDelete").addEventListener("click", deleteHabit)
}

function openCreateModal() {
  editingHabitId = null
  document.getElementById("modalTitle").textContent = "Criar Hábito"
  document.getElementById("btnSubmit").textContent = "Criar Hábito"
  document.getElementById("btnDelete").style.display = "none"
  document.getElementById("habitForm").reset()
  document.getElementById("habitId").value = ""

  selectedIcon = "💧"
  selectedColor = "#06b6d4"
  selectedType = "saudavel"

  document.getElementById("selectedIcon").textContent = selectedIcon
  document.getElementById("iconSelector").style.background =
    `linear-gradient(135deg, ${selectedColor} 0%, ${adjustColor(selectedColor, -20)} 100%)`

  document.querySelectorAll(".color-option").forEach((btn) => {
    btn.classList.remove("active")
    if (btn.dataset.color === selectedColor) btn.classList.add("active")
  })

  document.querySelectorAll(".btn-toggle").forEach((btn) => {
    btn.classList.remove("active")
    if (btn.dataset.type === selectedType) btn.classList.add("active")
  })

  document.querySelectorAll(".day-btn").forEach((btn) => btn.classList.add("active"))

  document.getElementById("modalOverlay").classList.add("active")
}

function openEditModal(habitId) {
  const habit = habits.find((h) => h.id === habitId)
  if (!habit) return

  editingHabitId = habitId
  document.getElementById("modalTitle").textContent = "Editar Hábito"
  document.getElementById("btnSubmit").textContent = "Salvar Alterações"
  document.getElementById("btnDelete").style.display = "block"

  document.getElementById("habitId").value = habit.id
  document.getElementById("habitName").value = habit.name
  document.getElementById("habitDescription").value = habit.description || ""
  document.getElementById("habitPeriod").value = habit.period
  document.getElementById("goalValue").value = habit.goalValue
  document.getElementById("goalUnit").value = habit.goalUnit

  selectedIcon = habit.icon
  selectedColor = habit.color
  selectedType = habit.type

  document.getElementById("selectedIcon").textContent = selectedIcon
  document.getElementById("iconSelector").style.background =
    `linear-gradient(135deg, ${selectedColor} 0%, ${adjustColor(selectedColor, -20)} 100%)`

  document.querySelectorAll(".color-option").forEach((btn) => {
    btn.classList.remove("active")
    if (btn.dataset.color === selectedColor) btn.classList.add("active")
  })

  document.querySelectorAll(".btn-toggle").forEach((btn) => {
    btn.classList.remove("active")
    if (btn.dataset.type === selectedType) btn.classList.add("active")
  })

  document.querySelectorAll(".day-btn").forEach((btn) => {
    btn.classList.remove("active")
    if (habit.days.includes(Number.parseInt(btn.dataset.day))) {
      btn.classList.add("active")
    }
  })

  document.getElementById("modalOverlay").classList.add("active")
}

function closeModal() {
  document.getElementById("modalOverlay").classList.remove("active")
  document.getElementById("iconPicker").style.display = "none"
}

function handleFormSubmit(e) {
  e.preventDefault()

  const name = document.getElementById("habitName").value
  const description = document.getElementById("habitDescription").value
  const period = document.getElementById("habitPeriod").value
  const goalValue = Number.parseInt(document.getElementById("goalValue").value)
  const goalUnit = document.getElementById("goalUnit").value

  const selectedDays = Array.from(document.querySelectorAll(".day-btn.active")).map((btn) =>
    Number.parseInt(btn.dataset.day),
  )

  const habit = {
    id: editingHabitId || Date.now().toString(),
    name,
    description,
    icon: selectedIcon,
    color: selectedColor,
    type: selectedType,
    period,
    goalValue,
    goalUnit,
    days: selectedDays,
    progress: editingHabitId ? habits.find((h) => h.id === editingHabitId).progress : {},
    streak: editingHabitId ? habits.find((h) => h.id === editingHabitId).streak : 0,
    bestStreak: editingHabitId ? habits.find((h) => h.id === editingHabitId).bestStreak : 0,
  }

  if (editingHabitId) {
    const index = habits.findIndex((h) => h.id === editingHabitId)
    habits[index] = habit
  } else {
    habits.push(habit)
  }

  saveHabits()
  renderHabits()
  closeModal()
}

function deleteHabit() {
  if (!confirm("Tem certeza que deseja excluir este hábito?")) return

  habits = habits.filter((h) => h.id !== editingHabitId)
  saveHabits()
  renderHabits()
  closeModal()
}

function renderHabits() {
  const morningGrid = document.getElementById("morningHabits")
  const afternoonGrid = document.getElementById("afternoonHabits")
  const eveningGrid = document.getElementById("eveningHabits")
  const allDayGrid = document.getElementById("allDayHabits")

  morningGrid.innerHTML = ""
  afternoonGrid.innerHTML = ""
  eveningGrid.innerHTML = ""
  allDayGrid.innerHTML = ""

  const sections = {
    morning: { grid: morningGrid, section: document.getElementById("morningSection") },
    afternoon: { grid: afternoonGrid, section: document.getElementById("afternoonSection") },
    evening: { grid: eveningGrid, section: document.getElementById("eveningSection") },
    allDay: { grid: allDayGrid, section: document.getElementById("allDaySection") },
  }

  Object.values(sections).forEach(({ section }) => {
    section.style.display = "none"
  })

  const filteredHabits = currentFilter === "all" ? habits : habits.filter((h) => h.period === currentFilter)

  filteredHabits.forEach((habit) => {
    const card = createHabitCard(habit)
    sections[habit.period].grid.appendChild(card)
    sections[habit.period].section.style.display = "block"
  })

  Object.entries(sections).forEach(([period, { grid, section }]) => {
    if (section.style.display === "block" && grid.children.length === 0) {
      grid.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📝</div>
          <div class="empty-state-text">Nenhum hábito neste período</div>
        </div>
      `
    }
  })
}

function createHabitCard(habit) {
  const card = document.createElement("div")
  card.className = "habit-card"
  card.style.borderColor = habit.color + "40"

  const today = new Date().getDay()
  const todayProgress = habit.progress[getTodayDateString()] || 0
  const progressPercent = (todayProgress / habit.goalValue) * 100

  card.innerHTML = `
    <div class="habit-card-header">
      <div class="habit-info">
        <div class="habit-icon" style="background: linear-gradient(135deg, ${habit.color} 0%, ${adjustColor(habit.color, -20)} 100%)">
          ${habit.icon}
        </div>
        <div class="habit-details">
          <div class="habit-name">${habit.name}</div>
          <div class="habit-goal">Meta: ${habit.goalValue} ${habit.goalUnit}/dia</div>
        </div>
      </div>
      <div class="habit-badge" style="background: linear-gradient(135deg, ${habit.color} 0%, ${adjustColor(habit.color, -20)} 100%)">
        🔥 ${habit.streak}
      </div>
    </div>
    
    <div class="habit-progress">
      <div class="progress-bar">
        <div class="progress-fill" style="width: ${Math.min(progressPercent, 100)}%; background: linear-gradient(135deg, ${habit.color} 0%, ${adjustColor(habit.color, -20)} 100%)"></div>
      </div>
      <div class="progress-text">${todayProgress} / ${habit.goalValue} ${habit.goalUnit}</div>
    </div>
    
    <div class="habit-days">
      ${generateDayIndicators(habit, today)}
    </div>
  `

  card.addEventListener("click", (e) => {
    if (!e.target.classList.contains("day-indicator")) {
      openEditModal(habit.id)
    }
  })

  return card
}

function generateDayIndicators(habit, today) {
  const last7Days = []
  for (let i = 6; i >= 0; i--) {
    const date = new Date()
    date.setDate(date.getDate() - i)
    last7Days.push(date)
  }

  return last7Days
    .map((date) => {
      const dayOfWeek = date.getDay()
      const dateString = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`
      const isToday = date.getDate() === new Date().getDate()
      const isScheduled = habit.days.includes(dayOfWeek)
      const progress = habit.progress[dateString] || 0
      const isCompleted = isScheduled && progress >= habit.goalValue

      const classes = ["day-indicator"]
      if (isCompleted) classes.push("completed")
      if (isToday) classes.push("today")

      return `<div class="${classes.join(" ")}" data-date="${dateString}" data-habit-id="${habit.id}" style="${isCompleted ? `background: linear-gradient(135deg, ${habit.color} 0%, ${adjustColor(habit.color, -20)} 100%)` : ""}">${daysOfWeekShort[dayOfWeek].charAt(0)}</div>`
    })
    .join("")
}

function updateStreak(habit) {
  const today = getTodayDateString()
  const yesterday = getYesterdayDateString()

  const todayProgress = habit.progress[today] || 0
  const yesterdayProgress = habit.progress[yesterday] || 0

  const todayComplete = todayProgress >= habit.goalValue
  const yesterdayComplete = yesterdayProgress >= habit.goalValue

  if (todayComplete) {
    if (yesterdayComplete || habit.streak === 0) {
      habit.streak += 1
    } else {
      habit.streak = 1
    }
  } else {
    if (!yesterdayComplete && habit.streak > 0) {
      habit.streak = 0
    }
  }

  if (habit.streak > habit.bestStreak) {
    habit.bestStreak = habit.streak
  }
}

function getTodayDateString() {
  const today = new Date()
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`
}

function getYesterdayDateString() {
  const yesterday = new Date()
  yesterday.setDate(yesterday.getDate() - 1)
  return `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, "0")}-${String(yesterday.getDate()).padStart(2, "0")}`
}

function checkPerfectDay() {
  const today = new Date().getDay()
  const habitsDueToday = habits.filter((h) => h.days.includes(today))
  if (habitsDueToday.length === 0) return false

  const todayString = getTodayDateString()
  return habitsDueToday.every((h) => (h.progress[todayString] || 0) >= h.goalValue)
}

function adjustColor(color, amount) {
  const clamp = (num) => Math.min(Math.max(num, 0), 255)
  const num = Number.parseInt(color.replace("#", ""), 16)
  const r = clamp((num >> 16) + amount)
  const g = clamp(((num >> 8) & 0x00ff) + amount)
  const b = clamp((num & 0x0000ff) + amount)
  return "#" + ((r << 16) | (g << 8) | b).toString(16).padStart(6, "0")
}

function saveHabits() {
  localStorage.setItem("habits", JSON.stringify(habits))
}

function loadHabits() {
  const saved = localStorage.getItem("habits")
  if (saved) {
    habits = JSON.parse(saved)
  }
}
