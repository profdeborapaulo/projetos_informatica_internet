function locomotiveAnimation() { 
    gsap.registerPlugin(ScrollTrigger);

    const locoScroll = new LocomotiveScroll({
        el: document.querySelector("#main"),
        smooth: true,
        tablet: { smooth: true },
        smartphone: { smooth: true }
    });

    locoScroll.on("scroll", ScrollTrigger.update);

    ScrollTrigger.scrollerProxy("#main", {
        scrollTop(value) {
            return arguments.length
                ? locoScroll.scrollTo(value, 0, 0)
                : locoScroll.scroll.instance.scroll.y;
        },
        getBoundingClientRect() {
            return {
                top: 0,
                left: 0,
                width: window.innerWidth,
                height: window.innerHeight
            };
        }
    });

    ScrollTrigger.addEventListener("refresh", () => locoScroll.update());
    ScrollTrigger.refresh();
}

function loadingAnimation() {
    var tl = gsap.timeline();
    tl.from("#page1", {
        opacity: 0,
        duration: 0.2,
        delay: 0.2
    });
    tl.from("#page1", {
        transform: "scaleX(0.7) scaleY(0.2) translateY(80%)",
        borderRadius: "150px",
        duration: 2,
        ease: "expo.out"
    });
    tl.from("nav", {
        opacity: 0,
        delay: -0.2
    });
    tl.from("#page1 h1, #page1 p, #page1 div", {
        opacity: 0,
        duration: 0.5,
        stagger: 0.2
    });
}

function navAnimation() {
    var nav = document.querySelector("nav");

    nav.addEventListener("mouseenter", function () {
        let tl = gsap.timeline();
        tl.to("#nav-bottom", { height: "21vh", duration: 0.5 });
        tl.to(".nav-part2 h5", { display: "block", duration: 0.1 });
        tl.to(".nav-part2 h5 span", {
            y: 0,
            stagger: { amount: 0.5 }
        });
    });

    nav.addEventListener("mouseleave", function () {
        let tl = gsap.timeline();
        tl.to(".nav-part2 h5 span", {
            y: 25,
            stagger: { amount: 0.2 }
        });
        tl.to(".nav-part2 h5", { display: "none", duration: 0.1 });
        tl.to("#nav-bottom", { height: 0, duration: 0.2 });
    });
}

function page2Animation() {
    var rightElems = document.querySelectorAll(".right-elem");

    rightElems.forEach(function (elem) {
        elem.addEventListener("mouseenter", function () {
            gsap.to(elem.childNodes[3], { opacity: 1, scale: 1 });
        });
        elem.addEventListener("mouseleave", function () {
            gsap.to(elem.childNodes[3], { opacity: 0, scale: 0 });
        });
        elem.addEventListener("mousemove", function (dets) {
            gsap.to(elem.childNodes[3], {
                x: dets.x - elem.getBoundingClientRect().x - 90,
                y: dets.y - elem.getBoundingClientRect().y - 215
            });
        });
    });
}

function page3VideoAnimation() {
    var page3Center = document.querySelector(".page3-center");
    var video = document.querySelector("#page3 video");

    if (page3Center && video) {
        page3Center.addEventListener("click", function () {
            video.play();
            gsap.to(video, {
                transform: "scaleX(1) scaleY(1)",
                opacity: 1,
                borderRadius: 0
            });
        });

        video.addEventListener("click", function () {
            video.pause();
            gsap.to(video, {
                transform: "scaleX(0.7) scaleY(0)",
                opacity: 0,
                borderRadius: "30px"
            });
        });
    }

    var sections = document.querySelectorAll(".sec-right");

    sections.forEach(function (elem) {
        elem.addEventListener("mouseenter", function () {
            elem.childNodes[3].style.opacity = 1;
            elem.childNodes[3].play();
        });
        elem.addEventListener("mouseleave", function () {
            elem.childNodes[3].style.opacity = 0;
            elem.childNodes[3].load();
        });
    });
}

function page6Animations() {
    gsap.from("#btm6-part2 h4", {
        x: 0,
        duration: 1,
        scrollTrigger: {
            trigger: "#btm6-part2",
            scroller: "#main",
            start: "top 80%",
            end: "top 10%",
            scrub: true
        }
    });
}

/* === Inicialização === */
locomotiveAnimation();
navAnimation();
page2Animation();
page3VideoAnimation();
page6Animations();
loadingAnimation();

const arrows = document.querySelectorAll(".toggle-arrow");
arrows.forEach(arrow => {
    arrow.addEventListener("click", e => {
        e.stopPropagation();
        const rightElem = arrow.closest(".right-elem");
        const extraText = rightElem.querySelector(".extra-text");
        extraText.classList.toggle("show");
        arrow.classList.toggle("active");
    });
});

/* === CURSOR PERSONALIZADO === */
var crsr = document.querySelector("#cursor");
var main = document.querySelector("#main");

document.addEventListener("mousemove", function (dets) {
    if (crsr) {
        crsr.style.left = dets.x + 20 + "px";
        crsr.style.top = dets.y + 20 + "px";
    }
});

gsap.from("#page1 h1,#page1 h2", {
    y: 10,
    rotate: 10,
    opacity: 0,
    delay: 0.3,
    duration: 0.7
});

var tl = gsap.timeline({
    scrollTrigger: {
        trigger: "#page1 h1",
        scroller: "#main",
        start: "top 27%",
        end: "top 0",
        scrub: 3
    }
});

tl.to("#page1 h1", { x: -100 }, "anim");
tl.to("#page1 h2", { x: 100 }, "anim");
tl.to("#page1 video", { width: "90%" }, "anim");

var tl2 = gsap.timeline({
    scrollTrigger: {
        trigger: "#page1 h1",
        scroller: "#main",
        start: "top -115%",
        end: "top -120%",
        scrub: 3
    }
});
tl2.to("#main", { backgroundColor: "#fff" });

var tl3 = gsap.timeline({
    scrollTrigger: {
        trigger: "#page1 h1",
        scroller: "#main",
        start: "top -280%",
        end: "top -300%",
        scrub: 3
    }
});
tl3.to("#main", { backgroundColor: "#0F0D0D" });

var boxes = document.querySelectorAll(".box");

boxes.forEach(function (elem) {
    elem.addEventListener("mouseenter", function () {
        var att = elem.getAttribute("data-image");
        crsr.style.width = "470px";
        crsr.style.height = "370px";
        crsr.style.borderRadius = "0";
        crsr.style.backgroundImage = `url(${att})`;
    });

    elem.addEventListener("mouseleave", function () {
        crsr.style.width = "20px";
        crsr.style.height = "20px";
        crsr.style.borderRadius = "50%";
        crsr.style.backgroundImage = "none";
    });
});

/* === NAV COLOR === */
var h4 = document.querySelectorAll("#nav h4");
var purple = document.querySelector("#purple");

h4.forEach(function (elem) {
    elem.addEventListener("mouseenter", function () {
        purple.style.display = "block";
        purple.style.opacity = "1";
    });

    elem.addEventListener("mouseleave", function () {
        purple.style.display = "none";
        purple.style.opacity = "0";
    });
});

var crsr = document.querySelector(".cursor");
var main = document.querySelector(".main");

document.addEventListener("mousemove", function (dets) {
    crsr.style.left = dets.x + 20 + "px";
    crsr.style.top = dets.y + 20 + "px";
});

const featureChips = document.querySelectorAll("#flex h4");

featureChips.forEach((chip) => {
    chip.addEventListener("click", function () {
        featureChips.forEach((c) => c.classList.remove("active"));
        this.classList.add("active");
    });
});

const items = document.querySelectorAll(".right-elem");

items.forEach(item => {
  const arrow = item.querySelector(".toggle-arrow");
  const text = item.querySelector(".extra-text");

  item.addEventListener("click", () => {
    const isOpen = text.classList.contains("show");

    document.querySelectorAll(".extra-text").forEach(t => t.classList.remove("show"));
    document.querySelectorAll(".toggle-arrow").forEach(a => a.classList.remove("active"));
o
    if (!isOpen) {
      text.classList.add("show");
      arrow.classList.add("active");
    }
  });

  arrow.addEventListener("click", (e) => {
    e.stopPropagation();
  });
});

console.log("Site HASE carregado com sucesso!");
