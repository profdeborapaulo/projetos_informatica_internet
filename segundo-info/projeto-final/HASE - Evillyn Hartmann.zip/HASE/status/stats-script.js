
let userStats = {
  level: 1,
  points: 0,
  streak: 0,
  bestStreak: 0,
  achievements: [],
  history: [],
  newAchievements: [],
}

let habits = []
let selectedTrophyImage = null
let currentUser = null 

const ACHIEVEMENTS = [
  {
    id: "first_habit",
    icon: "🌱",
    name: "Primeira Semente",
    desc: "Crie seu primeiro hábito",
    customImage: null,
  },
  {
    id: "habit_master",
    icon: "🎯",
    name: "Mestre dos Hábitos",
    desc: "Crie 5 hábitos",
    customImage: null,
  },
  {
    id: "week_warrior",
    icon: "⚔️",
    name: "Guerreiro Semanal",
    desc: "Sequência de 7 dias",
    customImage: null,
  },
  {
    id: "month_legend",
    icon: "👑",
    name: "Lenda Mensal",
    desc: "Sequência de 30 dias",
    customImage: null,
  },
  {
    id: "perfect_day",
    icon: "✨",
    name: "Dia Perfeito",
    desc: "Todos os hábitos em 1 dia",
    customImage: null,
  },
  {
    id: "early_bird",
    icon: "🌅",
    name: "Pássaro Madrugador",
    desc: "10 hábitos matinais",
    customImage: null,
  },
  {
    id: "night_owl",
    icon: "🦉",
    name: "Coruja Noturna",
    desc: "10 hábitos noturnos",
    customImage: null,
  },
  {
    id: "level_5",
    icon: "⭐",
    name: "Estrela em Ascensão",
    desc: "Alcance o nível 5",
    customImage: null,
  },
  {
    id: "level_10",
    icon: "💎",
    name: "Diamante",
    desc: "Alcance o nível 10",
    customImage: null,
  },
  {
    id: "points_1000",
    icon: "💯",
    name: "Milionário de Pontos",
    desc: "Acumule 1000 pontos",
    customImage: null,
  },
]

const API_URL = "http://localhost:3000"

document.addEventListener("DOMContentLoaded", async () => {
  checkUserSession()
  await loadDataFromLocalStorage() 
  renderStats()
  checkForNewTrophies()
  setupTrophyCustomization()

  // Close trophy modal
  document.getElementById("closeTrophyModal").addEventListener("click", closeTrophyModal)
})

function checkUserSession() {
  const userStr = localStorage.getItem("currentUser")
  if (!userStr) {
    window.location.href = "../login/login.htmll"
    return
  }
  currentUser = JSON.parse(userStr)
}

function getUserStorageKey(key) {
  return `${key}_${currentUser.email}`
}

function setupTrophyCustomization() {
  const fileInput = document.getElementById("trophyImageUpload")
  const selector = document.getElementById("trophySelector")
  const applyBtn = document.getElementById("applyTrophyImage")

  ACHIEVEMENTS.forEach((ach) => {
    const option = document.createElement("option")
    option.value = ach.id
    option.textContent = `${ach.icon} ${ach.name}`
    selector.appendChild(option)
  })

  fileInput.addEventListener("change", (e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        selectedTrophyImage = event.target.result
        showNotification("Imagem carregada! Selecione um troféu e clique em APLICAR.", "success")
      }
      reader.readAsDataURL(file)
    }
  })

  applyBtn.addEventListener("click", () => {
    const selectedAchievementId = selector.value
    if (!selectedAchievementId) {
      showNotification("Selecione um troféu primeiro!", "error")
      return
    }
    if (!selectedTrophyImage) {
      showNotification("Carregue uma imagem primeiro!", "error")
      return
    }

    const achievement = ACHIEVEMENTS.find((ach) => ach.id === selectedAchievementId)
    if (achievement) {
      achievement.customImage = selectedTrophyImage
      saveCustomImages()
      renderTrophies()
      showNotification(`Imagem aplicada ao troféu "${achievement.name}"!`, "success")
      selectedTrophyImage = null
      fileInput.value = ""
    }
  })
}

function showNotification(message, type = "success") {
  const notification = document.createElement("div")
  notification.className = `notification notification-${type}`
  notification.textContent = message

  const styles = {
    position: "fixed",
    top: "20px",
    right: "20px",
    background: type === "success" ? "#10b981" : type === "error" ? "#ef4444" : "#3b82f6",
    color: "white",
    padding: "1rem 1.5rem",
    borderRadius: "8px",
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.3)",
    zIndex: "10000",
    fontWeight: "bold",
    fontSize: "0.625rem",
    animation: "slideIn 0.3s ease, fadeOut 0.3s ease 2.7s",
    maxWidth: "300px",
    fontFamily: "'Press Start 2P', cursive",
  }

  Object.assign(notification.style, styles)

  document.body.appendChild(notification)

  setTimeout(() => {
    notification.remove()
  }, 3000)
}

function saveCustomImages() {
  const achievementsWithImages = ACHIEVEMENTS.map((ach) => ({
    id: ach.id,
    customImage: ach.customImage,
  }))
  localStorage.setItem(getUserStorageKey("achievementsCustomImages"), JSON.stringify(achievementsWithImages))
}

async function loadDataFromLocalStorage() {
  const savedHabits = localStorage.getItem(getUserStorageKey("habits"))
  const savedStats = localStorage.getItem(getUserStorageKey("userStats"))

  if (savedHabits) {
    habits = JSON.parse(savedHabits)
  }

  if (savedStats) {
    userStats = JSON.parse(savedStats)
    userStats.newAchievements = [] 
  }

  const savedAchievementsImages = localStorage.getItem(getUserStorageKey("achievementsCustomImages"))
  if (savedAchievementsImages) {
    const customImages = JSON.parse(savedAchievementsImages)
    customImages.forEach((saved) => {
      const achievement = ACHIEVEMENTS.find((ach) => ach.id === saved.id)
      if (achievement && saved.customImage) {
        achievement.customImage = saved.customImage
      }
    })
  }
}

function renderStats() {
  document.getElementById("playerLevel").textContent = userStats.level
  document.getElementById("playerXP").textContent = userStats.points
  document.getElementById("playerStreak").textContent = userStats.streak

  const currentLevelXP = (userStats.level - 1) * 100
  const nextLevelXP = userStats.level * 100
  const xpInLevel = userStats.points - currentLevelXP
  const xpNeeded = nextLevelXP - currentLevelXP
  const xpPercent = (xpInLevel / xpNeeded) * 100

  document.getElementById("xpFillPixel").style.width = `${xpPercent}%`
  document.getElementById("xpTextPixel").textContent = `${xpInLevel} / ${xpNeeded} XP`

  renderTrophies()

  renderHistory()

  renderSummary()
}

function renderTrophies() {
  const trophiesGrid = document.getElementById("trophiesGrid")
  trophiesGrid.innerHTML = ""

  ACHIEVEMENTS.forEach((achievement) => {
    const isUnlocked = userStats.achievements.includes(achievement.id)
    const isNew = userStats.newAchievements && userStats.newAchievements.includes(achievement.id)

    const trophyCard = document.createElement("div")
    trophyCard.className = `trophy-card ${isUnlocked ? "unlocked" : "locked"}`

    if (isUnlocked) {
      trophyCard.addEventListener("click", () => {
        showTrophyModal(achievement)
      })
    }

    const iconHtml = achievement.customImage
      ? `<img src="${achievement.customImage}" class="trophy-custom-img" style="max-width: 100%; max-height: 60px; object-fit: contain;" />`
      : achievement.icon

    trophyCard.innerHTML = `
      ${isNew ? '<div class="trophy-new-badge">NOVO!</div>' : ""}
      <div class="trophy-card-icon">${iconHtml}</div>
      <div class="trophy-card-name">${achievement.name}</div>
      <div class="trophy-card-desc">${achievement.desc}</div>
    `

    trophiesGrid.appendChild(trophyCard)
  })
}

function renderHistory() {
  const historyList = document.getElementById("historyList")
  historyList.innerHTML = ""

  if (userStats.history.length === 0) {
    historyList.innerHTML = `
      <div class="history-item">
        <div class="history-icon">📝</div>
        <div class="history-content">
          <div class="history-action">Nenhuma atividade ainda</div>
          <div class="history-details">Comece criando e completando hábitos!</div>
        </div>
      </div>
    `
    return
  }

  const recentHistory = userStats.history.slice(-20).reverse()

  recentHistory.forEach((item) => {
    const historyItem = document.createElement("div")
    historyItem.className = "history-item"

    let icon = "📝"
    let actionText = ""

    if (item.action === "habit_created") {
      icon = "🌱"
      actionText = "HÁBITO CRIADO"
    } else if (item.action === "habit_completed") {
      icon = "✅"
      actionText = "HÁBITO CONCLUÍDO"
    } else if (item.action === "achievement_unlocked") {
      icon = "🏆"
      actionText = "TROFÉU DESBLOQUEADO"
    } else if (item.action === "level_up") {
      icon = "⬆️"
      actionText = "LEVEL UP"
    }

    const date = new Date(item.timestamp)
    const timeStr = date.toLocaleString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    })

    historyItem.innerHTML = `
      <div class="history-icon">${icon}</div>
      <div class="history-content">
        <div class="history-action">${actionText}</div>
        <div class="history-details">${item.details}</div>
        <div class="history-time">${timeStr}</div>
      </div>
    `

    historyList.appendChild(historyItem)
  })
}

function renderSummary() {
  const today = new Date().getDay()
  const habitsDueToday = habits.filter((h) => h.days.includes(today))
  const completedToday = habitsDueToday.filter((h) => h.completedDays.includes(today)).length
  const completionRate = habitsDueToday.length > 0 ? Math.round((completedToday / habitsDueToday.length) * 100) : 0

  document.getElementById("totalHabitsPixel").textContent = habits.length
  document.getElementById("completedTodayPixel").textContent = completedToday
  document.getElementById("completionRatePixel").textContent = `${completionRate}%`
  document.getElementById("bestStreakPixel").textContent = userStats.bestStreak
}

function checkForNewTrophies() {
  if (userStats.newAchievements && userStats.newAchievements.length > 0) {
    const firstNewId = userStats.newAchievements[0]
    const achievement = ACHIEVEMENTS.find((a) => a.id === firstNewId)

    if (achievement) {
      setTimeout(() => {
        showTrophyModal(achievement, true)
      }, 500)
    }
  }
}

function showTrophyModal(achievement, isNew = false) {
  const modal = document.getElementById("trophyModal")
  const iconSpan = document.getElementById("trophyIcon")
  const customImage = document.getElementById("trophyCustomImage")

  if (achievement.customImage) {
    iconSpan.style.display = "none"
    customImage.src = achievement.customImage
    customImage.style.display = "block"
  } else {
    iconSpan.textContent = achievement.icon
    iconSpan.style.display = "block"
    customImage.style.display = "none"
  }

  document.getElementById("trophyName").textContent = achievement.name
  document.getElementById("trophyDesc").textContent = achievement.desc

  modal.classList.add("active")

  if (isNew && userStats.newAchievements) {
    userStats.newAchievements = userStats.newAchievements.filter((id) => id !== achievement.id)
    localStorage.setItem(getUserStorageKey("userStats"), JSON.stringify(userStats))

    renderTrophies()
  }
}

function closeTrophyModal() {
  const modal = document.getElementById("trophyModal")
  modal.classList.remove("active")

  if (userStats.newAchievements && userStats.newAchievements.length > 0) {
    setTimeout(() => {
      checkForNewTrophies()
    }, 300)
  }
}
